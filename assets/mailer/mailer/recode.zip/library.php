<?php
error_reporting(0);
define("mail.hub4tech.com", "mail.hub4tech.com"); //Hostname of the mail server
define("25", "25"); //Port of the SMTP like to be 25, 80, 465 or 587
define("info@hub4tech.com", "info@hub4tech.com"); //Username for SMTP authentication any valid email created in your domain
define("!nf0@T$ch", "!nf0@T$ch"); //Password for SMTP authentication
?>